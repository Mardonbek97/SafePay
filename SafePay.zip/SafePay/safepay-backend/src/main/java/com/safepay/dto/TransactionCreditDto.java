package com.safepay.dto;

import com.safepay.entity.Customer;
import com.safepay.enums.TransactionStatus;

import java.time.LocalDateTime;

public record TransactionCreditDto(Customer customerCreditor,
                                   Double transactionAmount,
                                   Double transactionCommission,
                                   TransactionStatus transactionStatus,
                                   LocalDateTime createdAt) {
}

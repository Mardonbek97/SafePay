package com.safepay.dto;

import com.safepay.entity.Customer;
import com.safepay.enums.TransactionStatus;

import java.time.LocalDateTime;

public record TransactionDebtDto(Customer customerDebtor,
                                 Double transactionAmount,
                                 TransactionStatus transactionStatus,
                                 String buyerPhone,
                                 String buyerName,
                                 LocalDateTime createdAt) {
}

package com.safepay.service;

import com.safepay.dto.UserDto;
import com.safepay.entity.User;
import com.safepay.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final UserRepository userRepository;

    public CustomerService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserDto create(UserDto dto) {
        User user = new User();
        user.setLogin(dto.login());
        user.setCustomer(dto.customer());
        user.setRole(dto.role());
        user.setPassword(dto.password());
        user.setCreatedAt(dto.createdAt());

        User savedUser = userRepository.save(user);

        return new UserDto(
                savedUser.getLogin(),
                savedUser.getPassword(),
                savedUser.getRole(),
                savedUser.getCustomer(),
                savedUser.getCreatedAt(),
                savedUser.getUpdateAt()
                );


    }

    /*public List<UserDto> getAll() {
        return userRepository.findAll()
                .stream()
                .map(user -> new UserDto(
                        user.getLogin(),
                        user.getPassword(),
                        user.getRole(),
                        user.getCustomer(),
                        user.getCreatedAt(),
                        user.getUpdateAt()
                ))
                .collect(Collectors.toList());
    }*/


    public List<UserDto> modifyUser(Long id, UserDto dto){

        User user = userRepository.findById(id)
                .orElseThrow(()->new RuntimeException("User not found!!!" + id));

        user.setLogin(dto.login());
        user.setCustomer(dto.customer());
        user.setRole(dto.role());
        user.setPassword(dto.password());

        User updatedUser = userRepository.save(user);

        return userRepository.findAll(Sort.by(Sort.Direction.DESC, "updateAt"))
                .stream()
                .map(u -> new UserDto(
                        updatedUser.getLogin(),
                        updatedUser.getPassword(),
                        updatedUser.getRole(),
                        updatedUser.getCustomer(),
                        updatedUser.getUpdateAt(),
                        updatedUser.getUpdateAt()
                ))
                .toList();
    }

}

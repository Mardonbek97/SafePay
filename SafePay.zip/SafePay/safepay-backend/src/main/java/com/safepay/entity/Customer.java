package com.safepay.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;

@Entity(name = "customer")
public class Customer {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @Column(name = "full_name")
        private String  fullName;
        private String  email;
        private String  phone;
        @Column(name = "is_active")
        private Boolean isActive;
        @CreatedDate
        private LocalDateTime  createdAt = LocalDateTime.now();;
        @UpdateTimestamp
        private LocalDateTime updateAt = LocalDateTime.now();;


}

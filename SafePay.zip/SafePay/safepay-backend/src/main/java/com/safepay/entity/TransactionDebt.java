package com.safepay.entity;

import com.safepay.enums.TransactionStatus;
import jakarta.persistence.*;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;
import java.util.Date;

@Entity(name = "transaction_debt")
public class TransactionDebt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "debtor_id")
    private Customer customerDebtor;

    private Double transactionAmount;
    @Enumerated(EnumType.ORDINAL)
    private TransactionStatus transactionStatus;

    private String buyerPhone;
    private String buyerName;
    @CreatedDate
    private Date  transactionDate;

    @CreatedDate
    private LocalDateTime  createdAt = LocalDateTime.now();;
    @UpdateTimestamp
    private LocalDateTime  updateAt = LocalDateTime.now();;


}

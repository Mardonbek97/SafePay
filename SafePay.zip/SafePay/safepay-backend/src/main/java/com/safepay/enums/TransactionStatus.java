package com.safepay.enums;

public enum TransactionStatus {
    HOLD, COMPLETED, CANCELLED;
}

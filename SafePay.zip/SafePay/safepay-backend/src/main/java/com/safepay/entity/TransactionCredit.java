package com.safepay.entity;

import com.safepay.enums.TransactionStatus;
import jakarta.persistence.*;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;
import java.util.Date;

@Entity(name = "transaction_credit")
public class TransactionCredit {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @ManyToOne
        @JoinColumn(name = "creditor_id")
        private Customer customerCreditor;

        private Double transactionAmount;
        private Double transactionCommission;  //1-3%
        @Enumerated(EnumType.ORDINAL)
        private TransactionStatus transactionStatus;

        @CreatedDate
        private Date transactionDate;

        @CreatedDate
        private LocalDateTime createdAt = LocalDateTime.now();;
        @UpdateTimestamp
        private LocalDateTime  updateAt = LocalDateTime.now();;



}

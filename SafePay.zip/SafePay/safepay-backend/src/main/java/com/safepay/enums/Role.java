package com.safepay.enums;

public enum Role {
    SUPERADMIN, ADMIN, USER;
}

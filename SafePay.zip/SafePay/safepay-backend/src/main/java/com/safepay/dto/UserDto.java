package com.safepay.dto;

import com.safepay.entity.Customer;
import com.safepay.enums.Role;

import java.time.LocalDateTime;

public record UserDto(String login,
                      String password,
                      Role role,
                      Customer customer,
                      LocalDateTime createdAt,
                      LocalDateTime updateAt) {
}

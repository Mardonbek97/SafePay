package com.safepay.repository;

import com.safepay.entity.TransactionDebt;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionDebtRepository extends JpaRepository<Long, TransactionDebt> {
}

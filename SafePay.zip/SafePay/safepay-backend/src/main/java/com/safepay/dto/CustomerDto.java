package com.safepay.dto;

public record CustomerDto(String fullName,
                          String email,
                          String phone) {

}

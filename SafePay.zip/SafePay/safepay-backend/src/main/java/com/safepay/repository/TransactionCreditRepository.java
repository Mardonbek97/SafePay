package com.safepay.repository;

import com.safepay.entity.TransactionCredit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionCreditRepository extends JpaRepository<Long, TransactionCredit> {
}

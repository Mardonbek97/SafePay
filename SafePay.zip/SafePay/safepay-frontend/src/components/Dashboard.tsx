import React, { useEffect, useState } from "react";
import api from "../services/api";
import BalanceCard from "./BalanceCard";

const Dashboard = () => {
  const [balance, setBalance] = useState<number>(0);
  const [sales, setSales] = useState<number>(0);

  useEffect(() => {
    api.get("/dashboard/balance").then(res => {
      const data = res.data[0];
      setBalance(data.amount);
      setSales(data.sales);
    });
  }, []);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", padding: "20px" }}>
      <BalanceCard amount={balance} />
      <div className="p-4 bg-white rounded-lg shadow">
        <h3>Savdolar</h3>
        <p style={{ fontSize: "24px", fontWeight: "bold" }}>{sales.toLocaleString()} so'm</p>
      </div>
    </div>
  );
};

export default Dashboard;
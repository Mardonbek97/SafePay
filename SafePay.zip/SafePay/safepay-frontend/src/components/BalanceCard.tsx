import React from "react";

interface Props {
  amount: number;
}

const BalanceCard: React.FC<Props> = ({ amount }) => {
  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h3>Balans</h3>
      <p style={{ fontSize: "24px", fontWeight: "bold" }}>{amount.toLocaleString()} so'm</p>
      <button style={{ marginTop: "10px", padding: "10px", backgroundColor: "blue", color: "white" }}>Olib tashlash</button>
    </div>
  );
};

export default BalanceCard;